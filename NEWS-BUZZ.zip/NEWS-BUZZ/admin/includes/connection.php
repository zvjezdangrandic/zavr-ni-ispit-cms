<?php
$conn = mysqli_connect("localhost","root","algebra12345","latest" ) or die ("error" . mysqli_error($conn));
?>